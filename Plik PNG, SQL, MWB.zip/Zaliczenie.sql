CREATE TABLE `Firma` (
  `idFirma` int NOT NULL AUTO_INCREMENT,
  `Nazwa` varchar(45) DEFAULT NULL,
  `Ulica` varchar(45) DEFAULT NULL,
  `Miejscowosc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idFirma`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE `Pracownicy` (
  `idPracownicy` int NOT NULL AUTO_INCREMENT,
  `Imie` varchar(45) DEFAULT NULL,
  `Nazwisko` varchar(45) DEFAULT NULL,
  `Stanowisko` varchar(45) DEFAULT NULL,
  `Miejscowosc` varchar(45) DEFAULT NULL,
  `Ulica` varchar(45) DEFAULT NULL,
  `Firma_idFirma` int NOT NULL,
  PRIMARY KEY (`idPracownicy`),
  KEY `fk_Pracownicy_Firma1_idx` (`Firma_idFirma`),
  CONSTRAINT `fk_Pracownicy_Firma1` FOREIGN KEY (`Firma_idFirma`) REFERENCES `Firma` (`idFirma`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE `Inne_pomieszczenia` (
  `idPomieszczenia` int NOT NULL AUTO_INCREMENT,
  `Nazwa_pomieszczenia` varchar(45) DEFAULT NULL,
  `Funkcja_pomieszczenia` varchar(45) DEFAULT NULL,
  `Firma_idFirma` int NOT NULL,
  PRIMARY KEY (`idPomieszczenia`),
  KEY `fk_Inne_pomieszczenia_Firma1_idx` (`Firma_idFirma`),
  CONSTRAINT `fk_Inne_pomieszczenia_Firma1` FOREIGN KEY (`Firma_idFirma`) REFERENCES `Firma` (`idFirma`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE `Magazyn` (
  `idMagazyn` int NOT NULL AUTO_INCREMENT,
  `Miejscowosc` varchar(45) DEFAULT NULL,
  `Ulica` varchar(45) DEFAULT NULL,
  `Firma_idFirma` int NOT NULL,
  PRIMARY KEY (`idMagazyn`),
  KEY `fk_Magazyn_Firma1_idx` (`Firma_idFirma`),
  CONSTRAINT `fk_Magazyn_Firma1` FOREIGN KEY (`Firma_idFirma`) REFERENCES `Firma` (`idFirma`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE `Maszynownia` (
  `idMaszynownia` int NOT NULL AUTO_INCREMENT,
  `Nazwa` varchar(45) DEFAULT NULL,
  `Ilosc` int DEFAULT NULL,
  `Funkcja` varchar(45) DEFAULT NULL,
  `Magazyn_idMagazyn` int NOT NULL,
  PRIMARY KEY (`idMaszynownia`),
  KEY `fk_Maszynownia_Magazyn1_idx` (`Magazyn_idMagazyn`),
  CONSTRAINT `fk_Maszynownia_Magazyn1` FOREIGN KEY (`Magazyn_idMagazyn`) REFERENCES `Magazyn` (`idMagazyn`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE TABLE `Odpady` (
  `idOdpady` int NOT NULL AUTO_INCREMENT,
  `Rodzaj_odpadu` enum('Trociny','Kora','Drewno_Spruchniale') DEFAULT NULL,
  `Ilosc` int DEFAULT NULL,
  `Jednostka_miary` varchar(45) DEFAULT NULL,
  `Magazyn_idMagazyn` int NOT NULL,
  PRIMARY KEY (`idOdpady`),
  KEY `fk_Odpady_Magazyn1_idx` (`Magazyn_idMagazyn`),
  CONSTRAINT `fk_Odpady_Magazyn1` FOREIGN KEY (`Magazyn_idMagazyn`) REFERENCES `Magazyn` (`idMagazyn`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci




CREATE TABLE `Drewno` (
  `idDrewno` int NOT NULL AUTO_INCREMENT,
  `Zastosowanie` enum('Termiczne','Budowlane') DEFAULT NULL,
  `Gatunek_Drewna` varchar(45) DEFAULT NULL,
  `Ilosc_sztuk` int DEFAULT NULL,
  `Magazyn_idMagazyn` int NOT NULL,
  PRIMARY KEY (`idDrewno`),
  KEY `fk_Drewno_Magazyn1_idx` (`Magazyn_idMagazyn`),
  CONSTRAINT `fk_Drewno_Magazyn1` FOREIGN KEY (`Magazyn_idMagazyn`) REFERENCES `Magazyn` (`idMagazyn`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci



CREATE DEFINER=`nosekn`@`localhost` TRIGGER `Pracownicy_insert` BEFORE INSERT ON `Pracownicy` FOR EACH ROW BEGIN   
IF NEW.Stanowisko = 'Zarządca Firmy'   
THEN     
SET NEW.Stanowisko = 'Zastępca Zarzadcy';   
END IF; 
END



CREATE DEFINER=`nosekn`@`localhost` TRIGGER `Drewno_insert_zaDuzo` BEFORE INSERT ON `Drewno` FOR EACH ROW BEGIN
  IF NEW.Ilosc_sztuk > 10000
  THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Za mało miejsca w Magazynie';
  END IF;
END



CREATE DEFINER=`nosekn`@`localhost` PROCEDURE `Odpady_wiecej`(IN Ilosc int)
BEGIN
Update Odpady set Ilosc = 1.2 * Ilosc where Rodzaj_odpadu = 'Trociny';
END


CREATE DEFINER=`nosekn`@`localhost` PROCEDURE `Odpady_wiecej`(IN Ilosc int)
BEGIN
Update Odpady set Ilosc = 1.2 * Ilosc where Rodzaj_odpadu = 'Trociny';
END


CREATE DEFINER=`nosekn`@`localhost` FUNCTION `Maszynownia_wiadomosc`(id int) RETURNS varchar(255) CHARSET utf8mb4
BEGIN
    DECLARE wiadomosc Varchar(255);
    SELECT Concat ('W maszynowni o id: ', id, ' znajduje sie taka ilosc towaru: ', ilosc) INTO @wiadomosc FROM Maszynownia where idMaszynownia=id;
    RETURN @wiadomosc;
END